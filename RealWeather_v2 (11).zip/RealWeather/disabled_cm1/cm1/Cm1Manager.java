package dev.realweather.cm1;

import dev.realweather.RealWeather;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Воспроизведение кадров CM1: сканирует папку, в фоне грузит окно шторма, по игровому времени интерполирует
 * между двумя кадрами. Данные доступны через current() (потокобезопасно). Визуализация работает в пределах одной JVM
 * (одиночная игра / хост LAN): клиент читает то же окно из памяти.
 */
public final class Cm1Manager {
    private static final class Frame {
        final Path path;
        long lastSize = -1;
        boolean stable;
        volatile boolean loading;
        volatile boolean failed;
        volatile boolean released;          // кадр уже проигран и выгружен — заново не грузим
        volatile Cm1Window win;
        double time = Double.NaN;

        Frame(Path p) { this.path = p; }
    }

    private static volatile boolean active;
    private static volatile Cm1Window current;
    private static volatile String lastError = "";
    private static final List<Frame> FRAMES = new ArrayList<>();
    private static final ExecutorService EX = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "RealWeather-CM1-loader");
        t.setDaemon(true);
        return t;
    });

    private static Path dir;
    private static String glob;
    private static Cm1Loader.Params params;
    private static volatile Cm1Mapping mapping;
    private static double mpbH, mpbV, speed, groundY, anchorX, anchorZ;
    private static volatile double windGain = 5.0;
    private static boolean started;
    private static long startTick, lastScan, lastBlend;
    private static double simStart;
    private static volatile boolean blendBusy;
    private static long version;
    private static double simNow;

    private Cm1Manager() {}

    public static boolean active() { return active; }

    public static double windGain() { return windGain; }

    public static Cm1Window current() { return current; }

    public static String lastError() { return lastError; }

    public static double simTime() { return simNow; }

    public static synchronized void start(Path outDir, String pattern, Cm1Loader.Params p, double mpbH, double vScale,
                                          double playbackSpeed, double groundY, double anchorX, double anchorZ, double gain) {
        stop();
        windGain = gain;
        dir = outDir; glob = pattern; params = p;
        Cm1Manager.mpbH = mpbH; Cm1Manager.mpbV = mpbH / vScale; speed = playbackSpeed; Cm1Manager.groundY = groundY;
        Cm1Manager.anchorX = anchorX; Cm1Manager.anchorZ = anchorZ;
        started = false; mapping = null; current = null; lastError = ""; simNow = 0;
        synchronized (FRAMES) { FRAMES.clear(); }
        active = true;
        lastScan = -1000;
    }

    public static synchronized void stop() {
        active = false;
        current = null;
        mapping = null;
        synchronized (FRAMES) { FRAMES.clear(); }
    }

    public static void setSpeed(double s) { speed = s; }

    public static void setTrackMode(int m) { if (params != null) params.trackMode = m; }

    public static String status() {
        int n;
        int loaded = 0;
        synchronized (FRAMES) {
            n = FRAMES.size();
            for (Frame f : FRAMES) if (f.win != null) loaded++;
        }
        Cm1Window w = current;
        return "кадров найдено: " + n + ", загружено в память: " + loaded + ", время симуляции: " + (int) simNow + " с, скорость x" + speed
                + (w != null ? String.format(", окно %d×%d×%d", w.nx, w.ny, w.nz) + (w.tornado ? String.format(", ТОРНАДО (ветер %.0f м/с, ζ=%.3f)", w.torWind, w.torZeta) : "") : ", окно не готово")
                + (lastError.isEmpty() ? "" : ", последняя ошибка: " + lastError);
    }

    /** Вызывается каждый серверный тик Оверворлда. */
    public static void tick(long gameTime) {
        if (!active) return;
        if (gameTime - lastScan >= 40) {
            lastScan = gameTime;
            scan();
        }
        List<Frame> snap;
        synchronized (FRAMES) { snap = new ArrayList<>(FRAMES); }
        // загрузка: первый стабильный непрогруженный кадр
        for (Frame f : snap) {
            if (f.stable && f.win == null && !f.loading && !f.failed && !f.released) {
                f.loading = true;
                EX.submit(() -> loadFrame(f));
                break;
            }
        }
        List<Frame> ready = new ArrayList<>();
        for (Frame f : snap) if (f.win != null) ready.add(f);
        if (ready.isEmpty()) return;
        ready.sort((a, b) -> Double.compare(a.time, b.time));

        if (!started) {
            started = true;
            startTick = gameTime;
            simStart = ready.get(0).time;
        }
        double sim = simStart + (gameTime - startTick) / 20.0 * speed;
        double last = ready.get(ready.size() - 1).time;
        if (sim > last) {                                  // ждём новые кадры, часы не убегают вперёд
            sim = last;
            startTick = gameTime - (long) ((last - simStart) / speed * 20.0);
        }
        simNow = sim;
        Frame a = ready.get(0), b = ready.get(0);
        for (int i = 0; i < ready.size(); i++) {
            if (ready.get(i).time <= sim) { a = ready.get(i); b = ready.get(Math.min(i + 1, ready.size() - 1)); }
        }
        // освобождаем память от кадров вне текущей пары
        for (Frame f : snap) if (f.win != null && f != a && f != b && f.time < a.time) { f.released = true; f.win = null; }
        if (gameTime - lastBlend >= 5 && !blendBusy) {
            lastBlend = gameTime;
            float t = b.time > a.time ? (float) ((sim - a.time) / (b.time - a.time)) : 0f;
            Frame fa = a, fb = b;
            blendBusy = true;
            EX.submit(() -> {
                try {
                    Cm1Window w = Cm1Window.blend(fa.win, fb.win, Math.max(0f, Math.min(1f, t)));
                    if (w == current) return;                  // тот же кадр — ничего не обновляем
                    w.setMapping(mapping);
                    w.version = ++version;
                    current = w;
                } catch (Throwable e) {
                    lastError = "смешение кадров: " + e;
                } finally {
                    blendBusy = false;
                }
            });
        }
    }

    private static void scan() {
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, glob)) {
            List<Path> files = new ArrayList<>();
            for (Path p : ds) files.add(p);
            Collections.sort(files);
            synchronized (FRAMES) {
                for (Path p : files) {
                    Frame f = null;
                    for (Frame x : FRAMES) if (x.path.equals(p)) { f = x; break; }
                    if (f == null) { f = new Frame(p); FRAMES.add(f); }
                    long size = Files.size(p);
                    long age = System.currentTimeMillis() - Files.getLastModifiedTime(p).toMillis();
                    f.stable = size > 0 && size == f.lastSize && age > 2000;     // файл дописан
                    f.lastSize = size;
                }
            }
        } catch (IOException e) {
            lastError = "сканирование папки " + dir + ": " + e.getMessage();
        }
    }

    private static void loadFrame(Frame f) {
        try {
            Cm1Window w = Cm1Loader.load(f.path, params);
            if (mapping == null) {
                mapping = new Cm1Mapping(anchorX, anchorZ, w.centerXm, w.centerYm, groundY, mpbH, mpbV);
            }
            w.setMapping(mapping);
            f.time = w.simTime;
            if (Double.isNaN(f.time)) f.time = 0;
            f.win = w;
            RealWeather.LOGGER.info("[CM1] загружен кадр {} (t={} с, окно {}×{}×{})", f.path.getFileName(), (int) w.simTime, w.nx, w.ny, w.nz);
        } catch (Throwable e) {
            f.failed = true;
            lastError = f.path.getFileName() + ": " + e.getMessage();
            RealWeather.LOGGER.warn("[CM1] не удалось прочитать {}: {}", f.path.getFileName(), e.toString());
        } finally {
            f.loading = false;
        }
    }

    /** Затемнение неба над точкой по облачной воде в колонке (0..1). */
    public static float darknessAt(double wx, double wz) {
        Cm1Window w = current;
        if (!active || w == null || w.mapping() == null) return 0f;
        float sum = w.cloudPathAt(wx, wz);
        return (float) (1.0 - Math.exp(-sum / 0.02));
    }

    public static float rainAt(double wx, double wz) {
        Cm1Window w = current;
        if (!active || w == null || w.mapping() == null) return 0f;
        return Math.min(1f, w.lowRainAt(wx, wz) / 0.003f);
    }
}
